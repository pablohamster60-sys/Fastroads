#!/usr/bin/env python3
"""Serve Fastroads locally or host online rooms with small player snapshots."""

import json
import math
import os
import re
import secrets
import string
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


ROOT = Path(__file__).resolve().parent
HOST = os.environ.get("FASTROADS_HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", os.environ.get("FASTROADS_PORT", "8000")))
PLAYER_TIMEOUT = 120
MAX_PLAYERS = 12
MAX_ROOMS = 500
ROOM_CODE_ALPHABET = string.ascii_uppercase + string.digits
ROOMS = {}
ROOMS_LOCK = threading.Lock()


def clean_name(value):
    value = "".join(
        char for char in str(value or "")[:20]
        if char.isprintable() and char not in "<>&"
    ).strip()
    return value or "Driver"


def clean_world(value):
    if not isinstance(value, dict):
        raise ValueError("Missing world settings.")
    world = {}
    for key in ("seed", "scene", "topography"):
        item = value.get(key)
        if not isinstance(item, str) or not item or len(item) > 40:
            raise ValueError("Invalid world settings.")
        world[key] = item
    return world


def prune_rooms(now):
    expired_rooms = []
    for code, room in ROOMS.items():
        expired_players = [
            player_id for player_id, player in room["players"].items()
            if now - player["updated"] > PLAYER_TIMEOUT
        ]
        for player_id in expired_players:
            del room["players"][player_id]
        if not room["players"]:
            expired_rooms.append(code)
    for code in expired_rooms:
        del ROOMS[code]


def player_snapshot(player_id, player):
    return {
        "id": player_id,
        "name": player["name"],
        "x": player["x"],
        "y": player["y"],
        "z": player["z"],
        "heading": player["heading"],
        "speed": player["speed"],
        "color": player["color"],
    }


class FastroadsHandler(SimpleHTTPRequestHandler):
    server_version = "FastroadsLAN/1.0"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_GET(self):
        if self.path == "/api/health":
            return self.send_json(
                200,
                {
                    "ok": True,
                    "localOnly": HOST in ("127.0.0.1", "localhost", "::1"),
                },
            )
        return super().do_GET()

    def do_POST(self):
        if not self.path.startswith("/api/"):
            return self.send_json(404, {"error": "Unknown API endpoint."})
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return self.send_json(400, {"error": "Invalid request length."})
        if content_length <= 0 or content_length > 8192:
            return self.send_json(413, {"error": "Request is empty or too large."})
        try:
            payload = json.loads(self.rfile.read(content_length))
            if not isinstance(payload, dict):
                raise ValueError("Expected a JSON object.")
            response, status = self.handle_api(self.path, payload)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
            return self.send_json(400, {"error": str(error)})
        except KeyError:
            return self.send_json(400, {"error": "Missing room or player details."})
        except Exception:
            self.log_error("Unexpected error handling %s", self.path)
            return self.send_json(500, {"error": "The multiplayer server encountered an error."})
        return self.send_json(status, response)

    def handle_api(self, path, payload):
        now = time.monotonic()
        with ROOMS_LOCK:
            prune_rooms(now)
            if path == "/api/rooms/create":
                world = clean_world(payload.get("world"))
                requested_code = str(payload.get("room", "")).strip().upper()
                if len(ROOMS) >= MAX_ROOMS:
                    return {
                        "error": "The room server is full. Try again later."
                    }, 503
                if requested_code:
                    if not re.fullmatch(r"[A-Z0-9]{3,6}", requested_code):
                        raise ValueError(
                            "Choose a room code with 3 to 6 letters or numbers."
                        )
                    if requested_code in ROOMS:
                        return {
                            "error": "That room code is already in use. Choose another code."
                        }, 409
                    room_code = requested_code
                else:
                    room_code = self.new_room_code()
                player_id = secrets.token_urlsafe(18)
                ROOMS[room_code] = {
                    "world": world,
                    "players": {
                        player_id: self.new_player(payload.get("name"), now, 0)
                    },
                }
                return {
                    "room": room_code,
                    "playerId": player_id,
                    "players": [],
                }, 201

            room_code = str(payload.get("room", "")).upper()
            room = ROOMS.get(room_code)
            if room is None:
                return {"error": "Room not found. Check the code and try again."}, 404

            if path == "/api/rooms/join":
                world = clean_world(payload.get("world"))
                if world != room["world"]:
                    return {
                        "error": "This room is using different terrain settings. Match the host's seed, scene, and terrain first."
                    }, 409
                if len(room["players"]) >= MAX_PLAYERS:
                    return {"error": "This room is full."}, 409
                player_id = secrets.token_urlsafe(18)
                room["players"][player_id] = self.new_player(
                    payload.get("name"), now, len(room["players"])
                )
                return {
                    "room": room_code,
                    "playerId": player_id,
                    "players": [
                        player_snapshot(pid, player)
                        for pid, player in room["players"].items()
                        if pid != player_id
                    ],
                }, 200

            player_id = str(payload.get("playerId", ""))
            player = room["players"].get(player_id)
            if player is None:
                return {"error": "Your room session expired. Rejoin the room."}, 404

            if path == "/api/rooms/leave":
                del room["players"][player_id]
                if not room["players"]:
                    del ROOMS[room_code]
                return {"ok": True}, 200

            if path == "/api/rooms/update":
                if clean_world(payload.get("world")) != room["world"]:
                    del room["players"][player_id]
                    if not room["players"]:
                        del ROOMS[room_code]
                    return {
                        "error": "World settings changed. Leave the room and rejoin after matching the host's seed, scene, and terrain."
                    }, 409
                position = payload.get("position")
                if not isinstance(position, dict):
                    raise ValueError("Invalid player position.")
                values = [
                    self.finite_number(position.get(key), key)
                    for key in ("x", "y", "z", "heading", "speed")
                ]
                if any(abs(value) > 10000000 for value in values):
                    raise ValueError("Player position is out of range.")
                player.update(
                    x=values[0],
                    y=values[1],
                    z=values[2],
                    heading=values[3],
                    speed=values[4],
                    updated=now,
                )
                return {
                    "players": [
                        player_snapshot(pid, other)
                        for pid, other in room["players"].items()
                        if pid != player_id
                    ]
                }, 200

        return {"error": "Unknown API endpoint."}, 404

    @staticmethod
    def finite_number(value, label):
        try:
            number = float(value)
        except (TypeError, ValueError):
            raise ValueError("Invalid " + label + ".")
        if not math.isfinite(number):
            raise ValueError("Invalid " + label + ".")
        return number

    @staticmethod
    def new_player(name, now, index):
        colors = (0x42C8F5, 0xF5A742, 0xB76AF5, 0x64D982, 0xF56991, 0xF5E65B)
        return {
            "name": clean_name(name),
            "x": 0,
            "y": 0,
            "z": 0,
            "heading": 0,
            "speed": 0,
            "color": colors[index % len(colors)],
            "updated": now,
        }

    @staticmethod
    def new_room_code():
        while True:
            code = "".join(secrets.choice(ROOM_CODE_ALPHABET) for _ in range(6))
            if code not in ROOMS:
                return code

    def send_json(self, status, data):
        body = json.dumps(data, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format_string, *args):
        if self.path.startswith("/api/"):
            return
        super().log_message(format_string, *args)


def main():
    try:
        server = ThreadingHTTPServer((HOST, PORT), FastroadsHandler)
    except OSError as error:
        if error.errno in (48, 98, 10048) or getattr(error, "winerror", None) == 10048:
            print(
                "Port {} is already in use. Close the older web-server window, "
                "then run run-fastroads.bat again.".format(PORT)
            )
            input("Press Enter to close this window.")
            return 1
        raise
    server.daemon_threads = True
    print("Fastroads server is ready at http://{}:{}/".format(HOST, PORT))
    if HOST in ("127.0.0.1", "localhost", "::1"):
        print("This local server accepts connections only from this computer.")
        print("Use the hosted Fastroads URL for online multiplayer.")
    print("Keep this window open while playing. Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Fastroads server...")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
