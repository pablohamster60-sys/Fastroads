import json
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import multiplayer_server


WORLD = {"seed": "test-seed", "scene": "test-scene", "topography": "test-terrain"}


class MultiplayerServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(
            ("127.0.0.1", 0), multiplayer_server.FastroadsHandler
        )
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base_url = "http://127.0.0.1:{}".format(cls.server.server_port)

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def setUp(self):
        with multiplayer_server.ROOMS_LOCK:
            multiplayer_server.ROOMS.clear()

    def post(self, path, payload):
        request = Request(
            self.base_url + path,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urlopen(request, timeout=3) as response:
            return response.status, json.loads(response.read())

    def test_health_reports_local_only(self):
        with urlopen(self.base_url + "/api/health", timeout=3) as response:
            self.assertEqual(response.status, 200)
            self.assertEqual(json.loads(response.read()), {"ok": True, "localOnly": True})

    def test_room_players_exchange_positions_and_leave(self):
        status, host = self.post(
            "/api/rooms/create",
            {"name": "Host", "room": "FAST", "world": WORLD},
        )
        self.assertEqual(status, 201)
        status, guest = self.post(
            "/api/rooms/join",
            {"name": "Guest", "room": host["room"], "world": WORLD},
        )
        self.assertEqual(status, 200)
        self.assertEqual(len(guest["players"]), 1)

        status, update = self.post(
            "/api/rooms/update",
            {
                "room": host["room"],
                "playerId": host["playerId"],
                "world": WORLD,
                "position": {
                    "x": 10,
                    "y": 2,
                    "z": -4,
                    "heading": 1,
                    "speed": 20,
                },
            },
        )
        self.assertEqual(status, 200)
        self.assertEqual(len(update["players"]), 1)
        self.assertEqual(update["players"][0]["x"], 0)

        status, update = self.post(
            "/api/rooms/update",
            {
                "room": guest["room"],
                "playerId": guest["playerId"],
                "world": WORLD,
                "position": {
                    "x": 30,
                    "y": 3,
                    "z": 5,
                    "heading": 0.5,
                    "speed": 12,
                },
            },
        )
        self.assertEqual(status, 200)
        self.assertEqual(update["players"][0]["x"], 10)

        self.post(
            "/api/rooms/leave",
            {"room": host["room"], "playerId": host["playerId"]},
        )
        status, update = self.post(
            "/api/rooms/update",
            {
                "room": guest["room"],
                "playerId": guest["playerId"],
                "world": WORLD,
                "position": {
                    "x": 0,
                    "y": 0,
                    "z": 0,
                    "heading": 0,
                    "speed": 0,
                },
            },
        )
        self.assertEqual(status, 200)
        self.assertEqual(update["players"], [])

    def test_world_mismatch_is_rejected(self):
        _, host = self.post(
            "/api/rooms/create",
            {"name": "Host", "room": "MATCH", "world": WORLD},
        )
        mismatched_world = dict(WORLD, seed="different-seed")
        with self.assertRaises(HTTPError) as error:
            self.post(
                "/api/rooms/join",
                {
                    "name": "Guest",
                    "room": host["room"],
                    "world": mismatched_world,
                },
            )
        self.assertEqual(error.exception.code, 409)


if __name__ == "__main__":
    unittest.main()
