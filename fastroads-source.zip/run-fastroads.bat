@echo off
setlocal
cd /d "%~dp0"
set "FASTROADS_HOST=127.0.0.1"
set "PORT=8000"

powershell -NoProfile -Command "try { $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/health' -TimeoutSec 1; if ($health.ok -and $health.localOnly) { exit 0 } } catch {}; $listener = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue; if ($listener) { exit 2 } else { exit 1 }"
if errorlevel 2 (
    echo Port 8000 is already being used by another server or an older Fastroads server.
    echo Close that server window before continuing. Older versions may accept network connections.
    pause
    exit /b 1
)
if errorlevel 1 goto start_server
echo Fastroads local server is already running on this computer.
start "" http://127.0.0.1:8000/
exit /b 0

:start_server
where py >nul 2>&1
if not errorlevel 1 (
    start "Fastroads LAN server" py -3 "%~dp0multiplayer_server.py"
) else (
    where python >nul 2>&1
    if errorlevel 1 (
        echo Python 3 was not found. Install Python 3, then run this file again.
        pause
        exit /b 1
    )
    start "Fastroads LAN server" python "%~dp0multiplayer_server.py"
)

timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:8000/
endlocal